for i in range(0,2**16):print(f'\t\t16\'b{bin(i)}:;'.replace("0b",""))
